$ErrorActionPreference = "Stop"

$projectRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$startScript = Join-Path $projectRoot "start_server.ps1"

Write-Host "Preparing the COMSOL MCP Python environment..."
& $startScript -SetupOnly
