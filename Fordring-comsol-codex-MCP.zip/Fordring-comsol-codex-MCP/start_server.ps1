param(
    [switch]$SetupOnly
)

$ErrorActionPreference = "Stop"

$projectRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$venvDir = Join-Path $projectRoot ".venv"
$pythonExe = Join-Path $venvDir "Scripts\python.exe"
$serverPath = Join-Path $projectRoot "server.py"
$requirementsPath = Join-Path $projectRoot "requirements.txt"

function Write-SetupLog {
    param([string]$Message)
    [Console]::Error.WriteLine($Message)
}

function New-ProjectVenv {
    Write-SetupLog "Creating Python virtual environment: $venvDir"
    if (Get-Command py -ErrorAction SilentlyContinue) {
        & py -3.12 -m venv $venvDir 2>&1 | ForEach-Object { Write-SetupLog $_ }
        if ($LASTEXITCODE -ne 0) { throw "Failed to create virtual environment with py launcher." }
        return
    }
    if (Get-Command python -ErrorAction SilentlyContinue) {
        & python -m venv $venvDir 2>&1 | ForEach-Object { Write-SetupLog $_ }
        if ($LASTEXITCODE -ne 0) { throw "Failed to create virtual environment with python." }
        return
    }
    throw "Python was not found. Install Python 3.10+ and rerun this script."
}

Set-Location $projectRoot

$needsInstall = $false
if (-not (Test-Path $pythonExe)) {
    New-ProjectVenv
    $needsInstall = $true
}

if (-not $needsInstall) {
    $missingDependencies = & $pythonExe -c "import server; print(','.join(server._missing_dependencies()))" 2>&1
    if ($LASTEXITCODE -ne 0) {
        $missingDependencies | ForEach-Object { Write-SetupLog $_ }
        $needsInstall = $true
    } elseif ($missingDependencies) {
        Write-SetupLog "Installing missing Python dependencies: $missingDependencies"
        $needsInstall = $true
    }
}

if ($needsInstall) {
    & $pythonExe -m pip install --upgrade pip 2>&1 | ForEach-Object { Write-SetupLog $_ }
    if ($LASTEXITCODE -ne 0) { throw "Failed to upgrade pip." }

    & $pythonExe -m pip install -r $requirementsPath 2>&1 | ForEach-Object { Write-SetupLog $_ }
    if ($LASTEXITCODE -ne 0) { throw "Failed to install Python dependencies." }
}

if ($SetupOnly) {
    Write-SetupLog "Python environment is ready: $pythonExe"
    exit 0
}

& $pythonExe $serverPath
