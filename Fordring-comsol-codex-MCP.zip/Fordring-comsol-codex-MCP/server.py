import csv
import json
import os
import re
import sys
import time
from pathlib import Path
from typing import Any

try:
    from dotenv import load_dotenv
except ModuleNotFoundError:
    load_dotenv = None

try:
    from mcp.server.fastmcp import FastMCP
except ModuleNotFoundError:
    FastMCP = None

try:
    import pyperclip
except ModuleNotFoundError:
    pyperclip = None

try:
    import psutil
except ModuleNotFoundError:
    psutil = None

try:
    from PIL import Image
except ModuleNotFoundError:
    Image = None

try:
    import pythoncom
    import win32gui
    import win32process
except ModuleNotFoundError:
    pythoncom = None
    win32gui = None
    win32process = None

try:
    from pywinauto import Application, Desktop, keyboard, timings
except ModuleNotFoundError:
    Application = None
    Desktop = None
    keyboard = None
    timings = None


if getattr(sys, "frozen", False):
    SERVER_DIR = Path(sys.executable).resolve().parent
else:
    SERVER_DIR = Path(__file__).resolve().parent

ENV_FILE = SERVER_DIR / "env.local"
if load_dotenv is not None:
    load_dotenv(ENV_FILE)

COMSOL_PROCESS_NAMES = tuple(
    name.strip().lower()
    for name in os.getenv("COMSOL_GUI_PROCESS_NAMES", "ComsolUI.exe,comsol.exe").split(",")
    if name.strip()
)
WINDOW_TITLE_PATTERN = os.getenv("COMSOL_GUI_WINDOW_TITLE_PATTERN", "COMSOL")
JAVA_SHELL_TITLE_PATTERN = os.getenv("COMSOL_JAVA_SHELL_TITLE_PATTERN", "Java Shell")
DEFAULT_TIMEOUT = float(os.getenv("COMSOL_GUI_TIMEOUT_SEC", "10"))
DESCENDANT_LIMIT = int(os.getenv("COMSOL_GUI_DESCENDANT_LIMIT", "1200"))
SHELL_SCAN_TIMEOUT = float(os.getenv("COMSOL_GUI_SHELL_SCAN_TIMEOUT_SEC", "8"))
AUTO_OPEN_SHELL = os.getenv("COMSOL_GUI_AUTO_OPEN_SHELL", "0").strip().lower() in {"1", "true", "yes"}
WINDOW_LIST_LIMIT = int(os.getenv("COMSOL_GUI_WINDOW_LIST_LIMIT", "20"))
SCREENSHOT_DIR = Path(os.getenv("COMSOL_GUI_SCREENSHOT_DIR", str(SERVER_DIR / "screenshots")))
COMSOL_REFERENCE_DIR = Path(os.getenv("COMSOL_REFERENCE_DIR", str(SERVER_DIR / "data")))
JAVA_SHELL_OUTPUT_ENABLED = os.getenv("COMSOL_JAVA_SHELL_OUTPUT_ENABLED", "1").strip().lower() in {
    "1",
    "true",
    "yes",
    "on",
}
JAVA_SHELL_OUTPUT_DIR = Path(os.getenv("COMSOL_JAVA_SHELL_OUTPUT_DIR", str(SERVER_DIR / "output")))
JAVA_SHELL_OUTPUT_FILE = os.getenv("COMSOL_JAVA_SHELL_OUTPUT_FILE", "java_shell_output.txt")
JAVA_SHELL_OUTPUT_CLEAR_BEFORE_EXEC = os.getenv(
    "COMSOL_JAVA_SHELL_OUTPUT_CLEAR_BEFORE_EXEC", "1"
).strip().lower() in {"1", "true", "yes", "on"}
JAVA_SHELL_OUTPUT_POLL_SEC = float(os.getenv("COMSOL_JAVA_SHELL_OUTPUT_POLL_SEC", "8"))
JAVA_SHELL_OUTPUT_POLL_INTERVAL_SEC = float(os.getenv("COMSOL_JAVA_SHELL_OUTPUT_POLL_INTERVAL_SEC", "0.25"))
JAVA_SHELL_OUTPUT_STABLE_SEC = float(os.getenv("COMSOL_JAVA_SHELL_OUTPUT_STABLE_SEC", "1.0"))
JAVA_SHELL_OUTPUT_DIRECT_FILE = os.getenv("COMSOL_JAVA_SHELL_OUTPUT_DIRECT_FILE", "1").strip().lower() in {
    "1",
    "true",
    "yes",
    "on",
}
AUTO_DISMISS_DIALOGS = os.getenv("COMSOL_GUI_AUTO_DISMISS_DIALOGS", "1").strip().lower() in {
    "1",
    "true",
    "yes",
    "on",
}
DISMISS_DIALOG_TITLE_PATTERN = os.getenv(
    "COMSOL_GUI_DISMISS_DIALOG_TITLE_PATTERN", r"^(错误|Error|警告|Warning|Exception)$"
)
DISMISS_DIALOG_TEXT_PATTERN = os.getenv(
    "COMSOL_GUI_DISMISS_DIALOG_TEXT_PATTERN",
    r"(Exception|Error|错误|警告|未知模型|cannot find symbol|access denied)",
)
DISMISS_DIALOG_BUTTON_PATTERN = os.getenv(
    "COMSOL_GUI_DISMISS_DIALOG_BUTTON_PATTERN", r"^(确定|OK|关闭|Close)$"
)
BLOCKED_SAVE_PATTERNS = (
    re.compile(r"\bmodel\s*\.\s*save\s*\(", re.IGNORECASE),
    re.compile(r"\bModelUtil\s*\.\s*save\s*\(", re.IGNORECASE),
    re.compile(r"\bsaveModel\s*\(", re.IGNORECASE),
)


def _missing_dependencies() -> list[str]:
    missing = []
    if load_dotenv is None:
        missing.append("python-dotenv")
    if FastMCP is None:
        missing.append("mcp")
    if Application is None or Desktop is None or keyboard is None or timings is None:
        missing.append("pywinauto")
    if pyperclip is None:
        missing.append("pyperclip")
    if psutil is None:
        missing.append("psutil")
    if Image is None:
        missing.append("Pillow")
    if win32gui is None or win32process is None or pythoncom is None:
        missing.append("pywin32")
    return missing


def _runtime_error_message() -> str:
    missing = _missing_dependencies()
    if not missing:
        return ""
    return (
        "Missing Python dependencies: "
        + ", ".join(missing)
        + f". Create `{SERVER_DIR}\\.venv` and install `{SERVER_DIR}\\requirements.txt`."
    )


def _ensure_runtime_ready() -> None:
    message = _runtime_error_message()
    if message:
        raise RuntimeError(message)


class _MissingFastMCP:
    def tool(self):
        def decorator(func):
            return func

        return decorator

    def resource(self, *_args, **_kwargs):
        def decorator(func):
            return func

        return decorator

    def run(self) -> None:
        raise RuntimeError(_runtime_error_message())


mcp = FastMCP("COMSOL GUI MCP") if FastMCP is not None else _MissingFastMCP()

COMSOL_REFERENCE_TABLES = {
    "physics_ids": {
        "path": COMSOL_REFERENCE_DIR / "comsol63_physics_ids.csv",
        "description": "COMSOL 6.3 physics interface IDs.",
    },
    "physics_feature_ids": {
        "path": COMSOL_REFERENCE_DIR / "comsol63_physics_feature_ids.csv",
        "description": "COMSOL 6.3 physics feature IDs.",
    },
    "boundary_feature_ids": {
        "path": COMSOL_REFERENCE_DIR / "comsol63_boundary_feature_ids.csv",
        "description": "COMSOL 6.3 boundary feature IDs.",
    },
}


def _matches(pattern: str, text: str) -> bool:
    if not pattern:
        return True
    try:
        return re.search(pattern, text or "", re.IGNORECASE) is not None
    except re.error:
        return pattern.lower() in (text or "").lower()


def _reference_table_info(table: str) -> dict[str, Any]:
    if table not in COMSOL_REFERENCE_TABLES:
        raise ValueError(
            "Unknown COMSOL reference table. Use one of: "
            + ", ".join(sorted(COMSOL_REFERENCE_TABLES))
        )
    path = COMSOL_REFERENCE_TABLES[table]["path"]
    return {
        "name": table,
        "description": COMSOL_REFERENCE_TABLES[table]["description"],
        "path": str(path),
        "uri": f"comsol63://{table}",
        "exists": path.exists(),
        "size_bytes": path.stat().st_size if path.exists() else None,
    }


def _read_reference_table_text(table: str) -> str:
    path = COMSOL_REFERENCE_TABLES[table]["path"]
    if not path.exists():
        raise FileNotFoundError(f"COMSOL reference CSV not found: {path}")
    return path.read_text(encoding="utf-8-sig")


def _row_matches_query(row: dict[str, str], terms: list[str]) -> bool:
    if not terms:
        return True
    haystack = " ".join(str(value or "").lower() for value in row.values())
    return all(term in haystack for term in terms)


def _search_reference_table(
    table: str,
    query: str = "",
    limit: int = 20,
    physics_id: str | None = None,
    feature_id: str | None = None,
    sdim_type: str | None = None,
) -> dict[str, Any]:
    if limit < 1:
        raise ValueError("limit must be at least 1.")
    limit = min(limit, 100)
    path = COMSOL_REFERENCE_TABLES[table]["path"]
    if not path.exists():
        raise FileNotFoundError(f"COMSOL reference CSV not found: {path}")

    terms = [term.lower() for term in query.split() if term.strip()]
    rows: list[dict[str, str]] = []
    scanned = 0
    with path.open("r", encoding="utf-8-sig", newline="") as csv_file:
        reader = csv.DictReader(csv_file)
        fields = reader.fieldnames or []
        for row in reader:
            scanned += 1
            if physics_id and row.get("PhysicsID", "").lower() != physics_id.lower():
                continue
            if feature_id and row.get("FeatureID", "").lower() != feature_id.lower():
                continue
            if sdim_type:
                sdim_values = [value.strip().lower() for value in row.get("SdimTypes", "").split(",")]
                if sdim_type.lower() not in sdim_values:
                    continue
            if not _row_matches_query(row, terms):
                continue
            rows.append(dict(row))
            if len(rows) >= limit:
                break

    return {
        "ok": True,
        "table": table,
        "fields": fields,
        "query": query,
        "limit": limit,
        "scanned_rows": scanned,
        "returned_rows": len(rows),
        "rows": rows,
    }


def _enum_visible_windows() -> list[dict[str, Any]]:
    _ensure_runtime_ready()
    windows: list[dict[str, Any]] = []

    def callback(hwnd, _extra):
        if not win32gui.IsWindowVisible(hwnd):
            return True
        title = win32gui.GetWindowText(hwnd) or ""
        try:
            _, pid = win32process.GetWindowThreadProcessId(hwnd)
        except Exception:
            pid = None
        windows.append({"hwnd": hwnd, "pid": pid, "title": title})
        return True

    try:
        win32gui.EnumWindows(callback, None)
    except Exception as exc:
        raise RuntimeError(
            "Windows desktop window enumeration failed. GUI automation must run with permission "
            f"to inspect the interactive desktop. Original error: {exc}"
        ) from exc
    return windows


def _process_name(pid: int | None) -> str | None:
    if pid is None or psutil is None:
        return None
    try:
        return psutil.Process(pid).name()
    except Exception:
        return None


def _find_comsol_processes() -> list[dict[str, Any]]:
    _ensure_runtime_ready()
    found: list[dict[str, Any]] = []
    for proc in psutil.process_iter(["pid", "name", "exe"]):
        try:
            name = proc.info.get("name") or ""
            if name.lower() in COMSOL_PROCESS_NAMES:
                found.append(
                    {
                        "pid": proc.info.get("pid"),
                        "name": name,
                        "path": proc.info.get("exe"),
                    }
                )
        except Exception:
            continue
    return found


def _is_probable_comsol_window(window: dict[str, Any], comsol_pids: set[int]) -> bool:
    title = window.get("title") or ""
    pid = window.get("pid")
    if pid in comsol_pids:
        return True
    if title and "COMSOL Multiphysics" in title and _matches(WINDOW_TITLE_PATTERN, title):
        return True
    return False


def _find_comsol_windows() -> list[dict[str, Any]]:
    processes = _find_comsol_processes()
    pids = {p["pid"] for p in processes if p.get("pid") is not None}
    windows = []
    for window in _enum_visible_windows():
        if _is_probable_comsol_window(window, pids):
            item = dict(window)
            item["process_name"] = _process_name(item.get("pid"))
            windows.append(item)
    windows.sort(key=_comsol_window_sort_key)
    if len(windows) <= WINDOW_LIST_LIMIT:
        return windows
    main_windows = [window for window in windows if _is_main_comsol_window(window)]
    shell_or_named = [
        window
        for window in windows
        if window not in main_windows
        and window.get("title")
        and _matches(JAVA_SHELL_TITLE_PATTERN, window.get("title") or "")
    ]
    remainder = [window for window in windows if window not in main_windows and window not in shell_or_named]
    return (main_windows + shell_or_named + remainder)[:WINDOW_LIST_LIMIT]


def _comsol_window_sort_key(window: dict[str, Any]) -> tuple[int, str]:
    title = window.get("title") or ""
    if "COMSOL Multiphysics" in title:
        return (0, title)
    if title and title not in {"ActiproWindowChromeShadow", "错误", "Error"}:
        return (1, title)
    return (2, title)


def _is_main_comsol_window(window: dict[str, Any]) -> bool:
    title = window.get("title") or ""
    return "COMSOL Multiphysics" in title


def _desktop():
    _ensure_runtime_ready()
    pythoncom.CoInitialize()
    timings.Timings.after_clickinput_wait = 0.2
    timings.Timings.window_find_timeout = DEFAULT_TIMEOUT
    return Desktop(backend="uia")


def _control_text(control) -> str:
    try:
        text = control.window_text()
        if text:
            return str(text)
    except Exception:
        pass
    try:
        text = control.element_info.name
        if text:
            return str(text)
    except Exception:
        pass
    return ""


def _walk_children_limited(root, limit: int = DESCENDANT_LIMIT, timeout_sec: float = SHELL_SCAN_TIMEOUT):
    deadline = time.monotonic() + timeout_sec
    stack = [root]
    seen = 0
    while stack and seen < limit and time.monotonic() < deadline:
        control = stack.pop()
        seen += 1
        yield control
        try:
            children = control.children()
        except Exception:
            children = []
        stack.extend(reversed(children))


def _has_edit_like_descendant(root) -> bool:
    for control in _walk_children_limited(root, limit=250, timeout_sec=2):
        try:
            ctype = control.element_info.control_type
        except Exception:
            ctype = ""
        if ctype in {"Edit", "Document"}:
            return True
    return False


def _nearest_shell_container(control):
    current = control
    fallback = control
    for _ in range(8):
        if current is None:
            break
        fallback = current
        if _has_edit_like_descendant(current):
            return current
        try:
            current = current.parent()
        except Exception:
            break
    return fallback


def _comsol_uia_roots() -> list[Any]:
    roots = []
    for window in _find_comsol_windows():
        if not _is_main_comsol_window(window):
            continue
        try:
            roots.append(_connect_top_window(window.get("hwnd")))
        except Exception:
            continue
    return roots


def _find_java_shell_window():
    for window in _find_comsol_windows():
        title = window.get("title") or ""
        if title and _matches(JAVA_SHELL_TITLE_PATTERN, title):
            try:
                return _connect_top_window(window.get("hwnd"))
            except Exception:
                continue

    # COMSOL often docks Java Shell as a pane inside the main window.
    for top in _comsol_uia_roots():
        for child in _walk_children_limited(top):
            title = _control_text(child)
            if title and _matches(JAVA_SHELL_TITLE_PATTERN, title):
                return _nearest_shell_container(child)
    return None


def _connect_top_window(hwnd: int | None = None):
    _ensure_runtime_ready()
    pythoncom.CoInitialize()
    if hwnd:
        app = Application(backend="uia").connect(handle=hwnd, timeout=DEFAULT_TIMEOUT)
        return app.window(handle=hwnd)

    windows = _find_comsol_windows()
    if not windows:
        raise RuntimeError(
            "No visible COMSOL Desktop window was found. Open COMSOL Desktop and the target model first."
        )

    selected = next((window for window in windows if _is_main_comsol_window(window)), windows[0])
    try:
        app = Application(backend="uia").connect(process=selected["pid"], timeout=DEFAULT_TIMEOUT)
        return app.top_window()
    except Exception:
        app = Application(backend="uia").connect(handle=selected["hwnd"], timeout=DEFAULT_TIMEOUT)
        return app.window(handle=selected["hwnd"])


def _focus_control(control) -> None:
    try:
        control.set_focus()
        time.sleep(0.2)
        return
    except Exception:
        pass
    try:
        control.click_input()
    except Exception:
        pass
    time.sleep(0.2)


def _safe_filename_part(value: str) -> str:
    clean = re.sub(r"[^A-Za-z0-9_.-]+", "_", value.strip())
    return clean[:80] or "comsol"


def _screenshot_path(prefix: str) -> Path:
    SCREENSHOT_DIR.mkdir(parents=True, exist_ok=True)
    stamp = time.strftime("%Y%m%d_%H%M%S")
    return SCREENSHOT_DIR / f"{_safe_filename_part(prefix)}_{stamp}.png"


def _capture_control(control, prefix: str) -> dict[str, Any]:
    _ensure_runtime_ready()
    _focus_control(control)
    try:
        image = control.capture_as_image()
    except Exception as exc:
        raise RuntimeError(f"Could not capture COMSOL GUI control: {exc}") from exc
    output_path = _screenshot_path(prefix)
    image.save(output_path)
    rect = control.rectangle()
    return {
        "ok": True,
        "path": str(output_path),
        "rect": {"left": rect.left, "top": rect.top, "right": rect.right, "bottom": rect.bottom},
        "width": rect.width(),
        "height": rect.height(),
    }


def _find_graphics_control():
    top = _connect_top_window()
    best = None
    best_area = 0
    for control in _walk_children_limited(top, limit=1800, timeout_sec=12):
        name = _control_text(control)
        try:
            ctype = control.element_info.control_type
            rect = control.rectangle()
        except Exception:
            continue
        if name and _matches(r"^(图形|Graphics)$", name):
            return control
        if ctype in {"Pane", "Custom"}:
            area = max(rect.width(), 0) * max(rect.height(), 0)
            if area > best_area and rect.width() > 300 and rect.height() > 250:
                best = control
                best_area = area
    return best


def _find_named_control(root, pattern: str):
    for control in _walk_children_limited(root, limit=1400, timeout_sec=10):
        if _matches(pattern, _control_text(control)):
            return control
    return None


def _try_click_named(root, pattern: str) -> bool:
    control = _find_named_control(root, pattern)
    if control is None:
        return False
    try:
        control.click_input()
        time.sleep(0.4)
        return True
    except Exception:
        return False


def _open_java_shell_from_gui() -> bool:
    """Best-effort automation for Home > Windows > Java Shell."""
    if not AUTO_OPEN_SHELL:
        return False

    top = _connect_top_window()
    _focus_control(top)

    click_sequences = [
        ["^Home$", "^Windows$", "Java Shell"],
        ["Home", "Windows", "Java Shell"],
        ["Windows", "Java Shell"],
    ]
    for sequence in click_sequences:
        current_root = top
        clicked_any = False
        for pattern in sequence:
            if _try_click_named(current_root, pattern):
                clicked_any = True
                time.sleep(0.5)
                current_root = top
        if clicked_any and _find_java_shell_window() is not None:
            return True

    # Keyboard fallback. This is layout-dependent, so failure is expected on some builds.
    for sequence in ("{VK_MENU}h", "{VK_MENU}w"):
        try:
            keyboard.send_keys(sequence, pause=0.05)
            time.sleep(0.6)
            if _find_java_shell_window() is not None:
                return True
        except Exception:
            continue
    return False


def _find_edit_like_descendants(root) -> list[Any]:
    controls = []
    for control in _walk_children_limited(root, limit=500, timeout_sec=3):
        try:
            ctype = control.element_info.control_type
        except Exception:
            ctype = ""
        try:
            name = control.element_info.name or ""
        except Exception:
            name = ""
        if ctype in {"Edit", "Document"} or "input" in name.lower() or "command" in name.lower():
            controls.append(control)
    return controls


def _find_shell_input(shell):
    edit_controls = _find_edit_like_descendants(shell)
    if not edit_controls:
        raise RuntimeError(
            "Java Shell was found, but no editable input control was detected. "
            "Click the Java Shell input area manually and retry."
        )

    prompt_rects = []
    for control in _walk_children_limited(shell, limit=500, timeout_sec=3):
        if _control_text(control).strip() != ">":
            continue
        try:
            prompt_rects.append(control.rectangle())
        except Exception:
            continue

    candidates: list[tuple[int, int, int, Any, dict[str, Any]]] = []
    for control in edit_controls:
        try:
            rect = control.rectangle()
            area = max(rect.width(), 0) * max(rect.height(), 0)
        except Exception:
            continue
        if rect.width() < 100 or rect.height() < 10:
            continue
        text = _control_text(control)
        stripped = text.strip()
        score = 0
        if not stripped:
            score += 1000
        elif len(stripped) < 5:
            score += 500
        elif len(stripped) < 80 and "\n" not in stripped:
            score += 120
        else:
            score -= min(len(stripped), 1000)
        if rect.height() <= 40:
            score += 250
        if rect.width() >= 300:
            score += 100
        if prompt_rects:
            prompt_distance = min(
                abs(rect.top - prompt.top) + max(prompt.right - rect.left, 0)
                for prompt in prompt_rects
            )
            if any(abs(rect.top - prompt.top) <= 12 and rect.left >= prompt.right for prompt in prompt_rects):
                score += 1000
            score -= min(prompt_distance, 500)
        else:
            prompt_distance = None
            score += rect.bottom // 10
        detail = {
            "score": score,
            "text_preview": stripped[:80],
            "rect": {"left": rect.left, "top": rect.top, "right": rect.right, "bottom": rect.bottom},
            "prompt_distance": prompt_distance,
        }
        candidates.append((score, rect.bottom, -area, control, detail))
    if candidates:
        candidates.sort(key=lambda item: (item[0], item[1], item[2]))
        selected = candidates[-1][3]
        try:
            selected._codex_input_candidates = [item[4] for item in candidates[-5:]]
        except Exception:
            pass
        return selected
    return edit_controls[-1]


def _focus_shell_input_control(input_control) -> dict[str, Any]:
    try:
        rect = input_control.rectangle()
        input_rect = {"left": rect.left, "top": rect.top, "right": rect.right, "bottom": rect.bottom}
    except Exception:
        rect = None
        input_rect = None
    try:
        input_text_preview = _control_text(input_control).strip()[:120]
    except Exception:
        input_text_preview = ""
    input_candidates = getattr(input_control, "_codex_input_candidates", None)
    try:
        input_control.set_focus()
    except Exception:
        pass
    try:
        if rect is not None:
            input_control.click_input(coords=(max(min(10, rect.width() - 1), 0), max(rect.height() // 2, 0)))
        else:
            input_control.click_input()
    except Exception:
        try:
            input_control.click_input()
        except Exception:
            pass
    time.sleep(0.2)
    return {
        "input_rect": input_rect,
        "input_text_preview": input_text_preview,
        "input_candidates": input_candidates,
    }


def _java_shell_output_path() -> Path:
    output_file = Path(JAVA_SHELL_OUTPUT_FILE)
    if output_file.is_absolute():
        return output_file
    return JAVA_SHELL_OUTPUT_DIR / output_file


def _clear_java_shell_output_file() -> dict[str, Any]:
    if not JAVA_SHELL_OUTPUT_ENABLED or not JAVA_SHELL_OUTPUT_CLEAR_BEFORE_EXEC:
        return {"output_file_enabled": JAVA_SHELL_OUTPUT_ENABLED, "output_file_cleared": False}

    output_path = _java_shell_output_path()
    output_path.parent.mkdir(parents=True, exist_ok=True)
    cleared = False
    clear_error = None
    for _ in range(10):
        try:
            output_path.unlink()
            cleared = True
            break
        except FileNotFoundError:
            cleared = True
            break
        except PermissionError as exc:
            clear_error = str(exc)
            try:
                output_path.write_text("", encoding="utf-8-sig")
                cleared = True
                clear_error = None
                break
            except Exception as truncate_exc:
                clear_error = f"{clear_error}; truncate failed: {truncate_exc}"
            time.sleep(0.2)
    return {
        "output_file_enabled": True,
        "output_file": str(output_path),
        "output_file_cleared": cleared,
        "output_file_clear_error": clear_error,
    }


def _read_java_shell_texts(shell) -> list[str]:
    texts: list[str] = []
    for control in _find_edit_like_descendants(shell):
        text = _control_text(control)
        if text and text not in texts:
            texts.append(text)
    return texts


def _read_control_texts(root, limit: int = 500, timeout_sec: float = 2.0) -> list[str]:
    texts: list[str] = []
    for control in _walk_children_limited(root, limit=limit, timeout_sec=timeout_sec):
        text = _control_text(control).strip()
        if text and text not in texts:
            texts.append(text)
    return texts


def _write_java_shell_output_file(
    texts: list[str], context: str, message: str | None = None
) -> dict[str, Any]:
    if not JAVA_SHELL_OUTPUT_ENABLED:
        return {"output_file_enabled": False, "output_file_written": False}

    output_path = _java_shell_output_path()
    output_path.parent.mkdir(parents=True, exist_ok=True)
    lines = [
        f"timestamp: {time.strftime('%Y-%m-%d %H:%M:%S')}",
        f"context: {context}",
        "",
    ]
    if texts:
        lines.extend(texts)
    elif message:
        lines.append(message)
    else:
        lines.append("COMSOL Java Shell output was not exposed through Windows UI Automation.")

    output_path.write_text("\n".join(lines).rstrip() + "\n", encoding="utf-8-sig")
    return {
        "output_file_enabled": True,
        "output_file": str(output_path),
        "output_file_written": True,
        "output_file_text_count": len(texts),
        "output_file_char_count": sum(len(text) for text in texts),
    }


def _read_java_shell_output_file_info() -> dict[str, Any]:
    if not JAVA_SHELL_OUTPUT_ENABLED:
        return {"output_file_enabled": False}

    output_path = _java_shell_output_path()
    if not output_path.exists():
        return {
            "output_file_enabled": True,
            "output_file": str(output_path),
            "output_file_exists": False,
            "output_file_written": False,
        }

    try:
        content = output_path.read_text(encoding="utf-8-sig", errors="replace")
    except Exception as exc:
        return {
            "output_file_enabled": True,
            "output_file": str(output_path),
            "output_file_exists": True,
            "output_file_read_error": str(exc),
        }

    return {
        "output_file_enabled": True,
        "output_file": str(output_path),
        "output_file_exists": True,
        "output_file_written": True,
        "output_file_char_count": len(content),
        "output_file_preview": content[:4000],
    }


def _read_java_shell_output_text() -> str:
    output_path = _java_shell_output_path()
    if not output_path.exists():
        return ""
    return output_path.read_text(encoding="utf-8-sig", errors="replace")


def _wait_for_direct_file_run(run_id: str, timeout_sec: float) -> dict[str, Any]:
    deadline = time.monotonic() + max(timeout_sec, JAVA_SHELL_OUTPUT_POLL_SEC, 0.5)
    end_marker = f"end_run_id: {run_id}"
    dismissed_dialogs: list[dict[str, Any]] = []
    while time.monotonic() < deadline:
        try:
            content = _read_java_shell_output_text()
        except Exception:
            content = ""
        if end_marker in content:
            return {
                "direct_file_run_completed": True,
                "direct_file_run_id": run_id,
                "direct_file_dismissed_dialogs": dismissed_dialogs,
            }
        dismissed_result = _dismiss_comsol_dialogs(timeout_sec=0.1)
        dismissed_dialogs.extend(dismissed_result.get("dismissed_dialogs") or [])
        time.sleep(max(JAVA_SHELL_OUTPUT_POLL_INTERVAL_SEC, 0.05))
    return {
        "direct_file_run_completed": False,
        "direct_file_run_id": run_id,
        "direct_file_dismissed_dialogs": dismissed_dialogs,
    }


def _java_string(value: str) -> str:
    return json.dumps(value, ensure_ascii=False)


def _indent_java_shell_code(code: str) -> str:
    return "\n".join("        " + line for line in code.splitlines())


def _redirect_java_output_calls(code: str) -> str:
    redirected = code.replace("System.out.", "__codexCaptureOut.").replace(
        "System.err.", "__codexCaptureOut."
    )
    return re.sub(
        r"\.printStackTrace\s*\(\s*System\.(?:out|err)\s*\)",
        ".printStackTrace(__codexCaptureOut)",
        redirected,
    )


def _wrap_java_shell_code_for_direct_file(code: str, run_id: str) -> str:
    output_path = _java_string(str(_java_shell_output_path()))
    run_id_literal = _java_string(run_id)
    redirected_code = _redirect_java_output_calls(code)
    return f"""{{
    java.io.File __codexOutputFile = new java.io.File({output_path});
    java.io.File __codexOutputDir = __codexOutputFile.getParentFile();
    if (__codexOutputDir != null) {{
        __codexOutputDir.mkdirs();
    }}
    java.io.PrintWriter __codexCaptureOut = null;
    try {{
        __codexCaptureOut = new java.io.PrintWriter(new java.io.OutputStreamWriter(new java.io.FileOutputStream(__codexOutputFile, false), "UTF-8"));
        __codexCaptureOut.println("timestamp: " + new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new java.util.Date()));
        __codexCaptureOut.println("context: execute_java_shell");
        __codexCaptureOut.println("run_id: " + {run_id_literal});
        __codexCaptureOut.println("");
        try {{
{_indent_java_shell_code(redirected_code)}
            __codexCaptureOut.println("");
            __codexCaptureOut.println("status: ok");
        }} catch (Throwable __codexThrowable) {{
            __codexCaptureOut.println("status: error");
            __codexCaptureOut.println("error_class: " + __codexThrowable.getClass().getName());
            __codexCaptureOut.println("error_message: " + String.valueOf(__codexThrowable.getMessage()));
            __codexCaptureOut.println("stack_trace:");
            __codexThrowable.printStackTrace(__codexCaptureOut);
        }}
        __codexCaptureOut.println("");
        __codexCaptureOut.println("end_run_id: " + {run_id_literal});
    }} finally {{
        if (__codexCaptureOut != null) {{
            __codexCaptureOut.close();
        }}
    }}
    System.out.println("codex_output_saved_to_file " + {run_id_literal});
}}"""


def _java_shell_text_signature(texts: list[str]) -> tuple[str, ...]:
    return tuple(texts)


def _new_java_shell_texts(before: list[str], after: list[str]) -> list[str]:
    before_counts: dict[str, int] = {}
    for text in before:
        before_counts[text] = before_counts.get(text, 0) + 1

    new_texts = []
    for text in after:
        count = before_counts.get(text, 0)
        if count:
            before_counts[text] = count - 1
        else:
            new_texts.append(text)
    return new_texts


def _wait_for_java_shell_text_change(shell, before: list[str], timeout_sec: float) -> list[str]:
    deadline = time.monotonic() + max(timeout_sec, JAVA_SHELL_OUTPUT_POLL_SEC, 0.5)
    before_signature = _java_shell_text_signature(before)
    latest = before
    changed_at = None
    while time.monotonic() < deadline:
        time.sleep(max(JAVA_SHELL_OUTPUT_POLL_INTERVAL_SEC, 0.05))
        _dismiss_comsol_dialogs(timeout_sec=0.1)
        current = _read_java_shell_texts(shell)
        current_signature = _java_shell_text_signature(current)
        if current_signature != _java_shell_text_signature(latest):
            latest = current
            changed_at = time.monotonic()
            continue
        if current_signature != before_signature and changed_at is not None:
            if time.monotonic() - changed_at >= max(JAVA_SHELL_OUTPUT_STABLE_SEC, 0.1):
                _dismiss_comsol_dialogs(timeout_sec=0.2)
                return _read_java_shell_texts(shell)
    return latest


def _window_text_from_hwnd(hwnd: int | None) -> str:
    if not hwnd:
        return ""
    try:
        return win32gui.GetWindowText(hwnd) or ""
    except Exception:
        return ""


def _is_comsol_pid(pid: int | None) -> bool:
    if pid is None:
        return False
    for process in _find_comsol_processes():
        if process.get("pid") == pid:
            return True
    return False


def _is_dialog_like_window(window: dict[str, Any]) -> bool:
    title = window.get("title") or ""
    pid = window.get("pid")
    if not _is_comsol_pid(pid):
        return False
    if _is_main_comsol_window(window):
        return False
    if not title or title in {"ActiproWindowChromeShadow"}:
        return False
    return True


def _control_has_matching_text(root, pattern: str) -> bool:
    for control in _walk_children_limited(root, limit=250, timeout_sec=1.5):
        if _matches(pattern, _control_text(control)):
            return True
    return False


def _click_matching_button(root, pattern: str) -> bool:
    for control in _walk_children_limited(root, limit=250, timeout_sec=1.5):
        try:
            ctype = control.element_info.control_type
        except Exception:
            ctype = ""
        if ctype != "Button":
            continue
        if not _matches(pattern, _control_text(control)):
            continue
        try:
            control.click_input()
            time.sleep(0.2)
            return True
        except Exception:
            continue
    return False


def _dismiss_comsol_dialogs(timeout_sec: float = 2.0) -> dict[str, Any]:
    if not AUTO_DISMISS_DIALOGS:
        return {"dialog_auto_dismiss_enabled": False, "dismissed_dialog_count": 0}

    dismissed: list[dict[str, Any]] = []
    deadline = time.monotonic() + max(timeout_sec, 0.1)
    while time.monotonic() < deadline:
        dismissed_this_pass = False
        for window in _enum_visible_windows():
            if not _is_dialog_like_window(window):
                continue
            title = window.get("title") or ""
            if not _matches(DISMISS_DIALOG_TITLE_PATTERN, title):
                try:
                    control = _connect_top_window(window.get("hwnd"))
                except Exception:
                    continue
                if not _control_has_matching_text(control, DISMISS_DIALOG_TEXT_PATTERN):
                    continue
            else:
                try:
                    control = _connect_top_window(window.get("hwnd"))
                except Exception:
                    continue

            texts = _read_control_texts(control, limit=350, timeout_sec=1.5)
            if _click_matching_button(control, DISMISS_DIALOG_BUTTON_PATTERN):
                dismissed.append(
                    {
                        "title": title,
                        "hwnd": window.get("hwnd"),
                        "pid": window.get("pid"),
                        "texts": texts,
                    }
                )
                dismissed_this_pass = True
                time.sleep(0.3)

        if not dismissed_this_pass:
            break

    return {
        "dialog_auto_dismiss_enabled": True,
        "dismissed_dialog_count": len(dismissed),
        "dismissed_dialogs": dismissed,
    }


def _dialog_texts_from_dismiss_result(dismissed_result: dict[str, Any]) -> list[str]:
    texts: list[str] = []
    for dialog in dismissed_result.get("dismissed_dialogs") or []:
        title = str(dialog.get("title") or "").strip()
        if title and title not in texts:
            texts.append(title)
        for text in dialog.get("texts") or []:
            text = str(text or "").strip()
            if text and text not in texts:
                texts.append(text)
    return texts


def _extend_unique(target: list[str], values: list[str]) -> None:
    for value in values:
        if value not in target:
            target.append(value)


def _filter_java_shell_error_texts(texts: list[str]) -> list[str]:
    filtered: list[str] = []
    keep_next = 0
    ui_labels = {
        "错误",
        "Error",
        "警告",
        "Warning",
        "系统",
        "关闭",
        "确定",
        "OK",
        "Close",
    }
    for text in texts:
        lines = text.splitlines() or [text]
        kept_lines: list[str] = []
        for line in lines:
            stripped = line.strip()
            if not stripped:
                continue
            if stripped in ui_labels:
                continue
            if "__codex" in stripped or stripped.startswith(("java.io.", "try {", "} catch", "} finally")):
                continue
            is_error_line = _matches(DISMISS_DIALOG_TEXT_PATTERN, stripped) or stripped.startswith(
                ("Error:", "Exception:", "Warning:")
            )
            is_context_line = keep_next > 0 or stripped.startswith("^") or set(stripped) <= {"-", "^", " "}
            if is_error_line:
                kept_lines.append(line)
                keep_next = 2
                continue
            if is_context_line:
                kept_lines.append(line)
                keep_next = max(keep_next - 1, 0)
        if kept_lines:
            filtered_text = "\n".join(kept_lines)
            if filtered_text not in filtered:
                filtered.append(filtered_text)
    return filtered or texts


def _texts_contain_error_marker(texts: list[str]) -> bool:
    for text in texts:
        for line in text.splitlines() or [text]:
            stripped = line.strip()
            if "__codex" in stripped:
                continue
            if stripped.startswith(("Error:", "Exception:", "Warning:")):
                return True
            if stripped in {"输入包含语法错误。", "Input contains a syntax error."}:
                return True
            if "cannot find symbol" in stripped or "incompatible types" in stripped:
                return True
    return False


def _validate_java_shell_code(code: str, allow_non_model_code: bool) -> list[str]:
    if not code or not code.strip():
        raise ValueError("Java Shell code is empty.")
    lines = [line.strip() for line in code.splitlines()]
    executable_lines = [line for line in lines if line and not line.startswith("//")]
    if not executable_lines:
        raise ValueError("Java Shell code contains no executable lines.")
    save_lines = [
        line
        for line in executable_lines
        if any(pattern.search(line) for pattern in BLOCKED_SAVE_PATTERNS)
    ]
    if save_lines:
        raise ValueError(
            "Rejected Java Shell code because GUI MCP must not save COMSOL models automatically. "
            "Make changes in the GUI model, verify them, and ask the user to save manually. "
            "Blocked lines: " + "; ".join(save_lines[:5])
        )
    if allow_non_model_code:
        return executable_lines

    bad_lines = []
    for line in executable_lines:
        if line in {";", "{", "}"}:
            continue
        if not line.startswith("model."):
            bad_lines.append(line)
    if bad_lines:
        raise ValueError(
            "Rejected Java Shell code because allow_non_model_code=false and these lines do not start with `model.`: "
            + "; ".join(bad_lines[:5])
        )
    return executable_lines


def _execute_in_shell(code: str, timeout_sec: float) -> dict[str, Any]:
    shell = _find_java_shell_window()
    if shell is None:
        opened = _open_java_shell_from_gui()
        shell = _find_java_shell_window() if opened else None
    if shell is None:
        raise RuntimeError(
            "Could not find or open COMSOL Java Shell. In COMSOL Desktop, open Home > Windows > Java Shell, "
            "click the Java Shell input area once, then retry."
        )

    run_id = f"{int(time.time() * 1000)}_{os.getpid()}"
    _focus_control(shell)
    input_control = _find_shell_input(shell)
    input_focus_result = _focus_shell_input_control(input_control)
    before_texts = _read_java_shell_texts(shell)
    file_result = _clear_java_shell_output_file()

    previous_clipboard = None
    try:
        previous_clipboard = pyperclip.paste()
    except Exception:
        pass

    try:
        submitted_code = (
            _wrap_java_shell_code_for_direct_file(code, run_id)
            if JAVA_SHELL_OUTPUT_ENABLED and JAVA_SHELL_OUTPUT_DIRECT_FILE
            else code
        )
        pyperclip.copy(submitted_code)
        _focus_shell_input_control(input_control)
        keyboard.send_keys("^a", pause=0.05)
        keyboard.send_keys("^v", pause=0.05)
        time.sleep(0.2)
        keyboard.send_keys("{VK_CONTROL down}{ENTER}{VK_CONTROL up}", pause=0.05)
        time.sleep(min(max(float(timeout_sec), 0.5), 2.0))
    finally:
        if previous_clipboard is not None:
            try:
                pyperclip.copy(previous_clipboard)
            except Exception:
                pass

    post_submit_texts = _read_java_shell_texts(shell)
    post_submit_new_texts = _new_java_shell_texts(before_texts, post_submit_texts)
    dismissed_result = _dismiss_comsol_dialogs(timeout_sec=2)
    if JAVA_SHELL_OUTPUT_ENABLED and JAVA_SHELL_OUTPUT_DIRECT_FILE:
        direct_run_result = _wait_for_direct_file_run(run_id, timeout_sec)
        file_result.update(_read_java_shell_output_file_info())
        texts = _read_java_shell_texts(shell)
        new_texts = _new_java_shell_texts(before_texts, texts)
        if not direct_run_result.get("direct_file_run_completed"):
            direct_dismissed_result = {
                "dismissed_dialogs": direct_run_result.get("direct_file_dismissed_dialogs") or []
            }
            fallback_texts: list[str] = []
            _extend_unique(fallback_texts, post_submit_new_texts)
            _extend_unique(fallback_texts, new_texts)
            if not _texts_contain_error_marker(fallback_texts):
                _extend_unique(fallback_texts, _dialog_texts_from_dismiss_result(dismissed_result))
                _extend_unique(fallback_texts, _dialog_texts_from_dismiss_result(direct_dismissed_result))
            if fallback_texts:
                fallback_texts = _filter_java_shell_error_texts(fallback_texts)
                file_result.update(
                    _write_java_shell_output_file(
                        fallback_texts,
                        context="execute_java_shell_compile_or_submission_error",
                        message=(
                            "COMSOL Java Shell did not execute the file-output wrapper; "
                            "captured visible Java Shell/dialog text directly through UI Automation."
                        ),
                    )
                )
                file_result.update(_read_java_shell_output_file_info())
            file_result["output_verification_error"] = (
                "Ctrl+Enter submission was not verified: output file does not contain this run's end marker."
            )
    else:
        direct_run_result = {"direct_file_run_completed": None, "direct_file_run_id": run_id}
        texts = _wait_for_java_shell_text_change(shell, before_texts, timeout_sec)
        new_texts = _new_java_shell_texts(before_texts, texts)
        if not new_texts and texts:
            new_texts = texts
        file_result.update(
            _write_java_shell_output_file(
                new_texts,
                context="execute_java_shell",
                message=(
                    "Command was submitted with Ctrl+Enter, but no new COMSOL Java Shell output was detected."
                ),
            )
        )
    return {
        "submitted": True,
        "java_shell_found": True,
        "note": "Command was submitted to COMSOL Java Shell with Ctrl+Enter.",
        "output_available": bool(new_texts) or bool(file_result.get("output_file_exists")),
        "texts": new_texts,
        "all_texts": texts,
        "direct_file_output": JAVA_SHELL_OUTPUT_ENABLED and JAVA_SHELL_OUTPUT_DIRECT_FILE,
        **input_focus_result,
        **direct_run_result,
        **dismissed_result,
        **file_result,
    }


@mcp.resource(
    "comsol63://physics_ids",
    name="comsol63_physics_ids",
    description="Raw CSV table of COMSOL 6.3 physics interface IDs.",
    mime_type="text/csv",
)
def read_comsol63_physics_ids_csv() -> str:
    """Read the COMSOL 6.3 physics interface ID CSV."""
    return _read_reference_table_text("physics_ids")


@mcp.resource(
    "comsol63://physics_feature_ids",
    name="comsol63_physics_feature_ids",
    description="Raw CSV table of COMSOL 6.3 physics feature IDs.",
    mime_type="text/csv",
)
def read_comsol63_physics_feature_ids_csv() -> str:
    """Read the COMSOL 6.3 physics feature ID CSV."""
    return _read_reference_table_text("physics_feature_ids")


@mcp.resource(
    "comsol63://boundary_feature_ids",
    name="comsol63_boundary_feature_ids",
    description="Raw CSV table of COMSOL 6.3 boundary feature IDs.",
    mime_type="text/csv",
)
def read_comsol63_boundary_feature_ids_csv() -> str:
    """Read the COMSOL 6.3 boundary feature ID CSV."""
    return _read_reference_table_text("boundary_feature_ids")


@mcp.tool()
def list_comsol_reference_tables() -> dict[str, Any]:
    """List bundled COMSOL 6.3 CSV reference tables."""
    return {
        "ok": True,
        "reference_dir": str(COMSOL_REFERENCE_DIR),
        "tables": [_reference_table_info(table) for table in sorted(COMSOL_REFERENCE_TABLES)],
    }


@mcp.tool()
def search_comsol_physics_ids(query: str = "", limit: int = 20, sdim_type: str | None = None) -> dict[str, Any]:
    """Search COMSOL 6.3 physics interface IDs by text and optional space dimension type."""
    return _search_reference_table("physics_ids", query=query, limit=limit, sdim_type=sdim_type)


@mcp.tool()
def search_comsol_physics_feature_ids(
    query: str = "",
    limit: int = 20,
    physics_id: str | None = None,
    feature_id: str | None = None,
    sdim_type: str | None = None,
) -> dict[str, Any]:
    """Search COMSOL 6.3 physics feature IDs by text and optional PhysicsID/FeatureID filters."""
    return _search_reference_table(
        "physics_feature_ids",
        query=query,
        limit=limit,
        physics_id=physics_id,
        feature_id=feature_id,
        sdim_type=sdim_type,
    )


@mcp.tool()
def search_comsol_boundary_feature_ids(
    query: str = "",
    limit: int = 20,
    physics_id: str | None = None,
    feature_id: str | None = None,
    sdim_type: str | None = None,
) -> dict[str, Any]:
    """Search COMSOL 6.3 boundary feature IDs by text and optional PhysicsID/FeatureID filters."""
    return _search_reference_table(
        "boundary_feature_ids",
        query=query,
        limit=limit,
        physics_id=physics_id,
        feature_id=feature_id,
        sdim_type=sdim_type,
    )


@mcp.tool()
def gui_status() -> dict[str, Any]:
    """List COMSOL GUI processes/windows and report whether Java Shell is visible."""
    _ensure_runtime_ready()
    processes = _find_comsol_processes()
    window_error = None
    shell_error = None
    try:
        windows = _find_comsol_windows()
    except Exception as exc:
        windows = []
        window_error = str(exc)
    try:
        shell = _find_java_shell_window() if window_error is None else None
    except Exception as exc:
        shell = None
        shell_error = str(exc)
    return {
        "ok": bool(processes or windows),
        "comsol_processes": processes,
        "comsol_windows": windows,
        "java_shell_detected": shell is not None,
        "java_shell_title": _control_text(shell) if shell is not None else None,
        "window_error": window_error,
        "java_shell_error": shell_error,
        "env": {
            "COMSOL_GUI_PROCESS_NAMES": ",".join(COMSOL_PROCESS_NAMES),
            "COMSOL_GUI_WINDOW_TITLE_PATTERN": WINDOW_TITLE_PATTERN,
            "COMSOL_JAVA_SHELL_TITLE_PATTERN": JAVA_SHELL_TITLE_PATTERN,
            "COMSOL_GUI_AUTO_OPEN_SHELL": AUTO_OPEN_SHELL,
            "COMSOL_GUI_WINDOW_LIST_LIMIT": WINDOW_LIST_LIMIT,
            "COMSOL_JAVA_SHELL_OUTPUT_ENABLED": JAVA_SHELL_OUTPUT_ENABLED,
            "COMSOL_JAVA_SHELL_OUTPUT_DIR": str(JAVA_SHELL_OUTPUT_DIR),
            "COMSOL_JAVA_SHELL_OUTPUT_FILE": JAVA_SHELL_OUTPUT_FILE,
            "COMSOL_JAVA_SHELL_OUTPUT_CLEAR_BEFORE_EXEC": JAVA_SHELL_OUTPUT_CLEAR_BEFORE_EXEC,
            "COMSOL_JAVA_SHELL_OUTPUT_POLL_SEC": JAVA_SHELL_OUTPUT_POLL_SEC,
            "COMSOL_JAVA_SHELL_OUTPUT_STABLE_SEC": JAVA_SHELL_OUTPUT_STABLE_SEC,
            "COMSOL_JAVA_SHELL_OUTPUT_DIRECT_FILE": JAVA_SHELL_OUTPUT_DIRECT_FILE,
            "COMSOL_GUI_AUTO_DISMISS_DIALOGS": AUTO_DISMISS_DIALOGS,
            "COMSOL_GUI_DISMISS_DIALOG_TITLE_PATTERN": DISMISS_DIALOG_TITLE_PATTERN,
            "COMSOL_GUI_DISMISS_DIALOG_TEXT_PATTERN": DISMISS_DIALOG_TEXT_PATTERN,
            "COMSOL_GUI_DISMISS_DIALOG_BUTTON_PATTERN": DISMISS_DIALOG_BUTTON_PATTERN,
        },
    }


@mcp.tool()
def ensure_java_shell() -> dict[str, Any]:
    """Find or open COMSOL Java Shell in the running Desktop GUI."""
    _ensure_runtime_ready()
    shell = _find_java_shell_window()
    if shell is not None:
        _focus_control(shell)
        return {"ok": True, "java_shell_detected": True, "title": _control_text(shell)}

    opened = _open_java_shell_from_gui()
    shell = _find_java_shell_window() if opened else None
    if shell is not None:
        _focus_control(shell)
        return {"ok": True, "java_shell_detected": True, "title": _control_text(shell)}

    return {
        "ok": False,
        "java_shell_detected": False,
        "manual_action": "Open COMSOL Desktop > Home > Windows > Java Shell, then retry.",
    }


@mcp.tool()
def execute_java_shell(
    code: str, allow_non_model_code: bool = False, timeout_sec: float = 30
) -> dict[str, Any]:
    """Paste Java API commands into COMSOL Java Shell and execute them with Ctrl+Enter.

    This tool intentionally rejects Java save calls. After GUI edits, ask the
    user to save the COMSOL model manually.
    """
    _ensure_runtime_ready()
    executable_lines = _validate_java_shell_code(code, allow_non_model_code)
    result = _execute_in_shell(code, timeout_sec)
    result.update(
        {
            "ok": True,
            "line_count": len(code.splitlines()),
            "executable_line_count": len(executable_lines),
            "allow_non_model_code": allow_non_model_code,
            "manual_save_required": True,
            "save_policy": "GUI MCP does not save COMSOL models automatically; ask the user to save manually.",
        }
    )
    return result


@mcp.tool()
def set_global_parameter(name: str, value: str, description: str | None = None) -> dict[str, Any]:
    """Set a global COMSOL parameter in the current GUI model through Java Shell."""
    if not re.match(r"^[A-Za-z_]\w*$", name or ""):
        raise ValueError("Parameter name must be a valid COMSOL-style identifier, e.g. codex_gui_mcp_probe.")
    lines = [f"model.param().set({_java_string(name)}, {_java_string(value)});"]
    if description:
        lines.append(f"model.param().descr({_java_string(name)}, {_java_string(description)});")
    code = "\n".join(lines)
    result = execute_java_shell(code=code, allow_non_model_code=False, timeout_sec=10)
    result.update({"parameter": name, "value": value, "description": description, "code": code})
    return result


@mcp.tool()
def get_java_shell_output() -> dict[str, Any]:
    """Best-effort read of visible Java Shell text."""
    _ensure_runtime_ready()
    shell = _find_java_shell_window()
    if shell is None:
        return {"ok": False, "output_available": False, "message": "Java Shell is not visible."}

    texts: list[str] = []
    texts = _read_java_shell_texts(shell)
    file_result = _write_java_shell_output_file(
        texts,
        context="get_java_shell_output",
        message="COMSOL Java Shell output may not be exposed through Windows UI Automation.",
    )
    return {
        "ok": True,
        "output_available": bool(texts),
        "texts": texts,
        "message": None if texts else "COMSOL Java Shell output may not be exposed through Windows UI Automation.",
        **file_result,
    }


@mcp.tool()
def capture_comsol_window() -> dict[str, Any]:
    """Capture the current COMSOL main window to a PNG file."""
    top = _connect_top_window()
    result = _capture_control(top, "comsol_window")
    result["target"] = "main_window"
    result["title"] = _control_text(top)
    return result


@mcp.tool()
def capture_graphics_panel() -> dict[str, Any]:
    """Capture the visible COMSOL graphics panel to a PNG file."""
    graphics = _find_graphics_control()
    if graphics is None:
        raise RuntimeError("Could not locate the COMSOL graphics panel. Use capture_comsol_window() instead.")
    result = _capture_control(graphics, "comsol_graphics")
    result["target"] = "graphics_panel"
    result["title"] = _control_text(graphics)
    return result


def main() -> None:
    _ensure_runtime_ready()
    mcp.run()


if __name__ == "__main__":
    main()
