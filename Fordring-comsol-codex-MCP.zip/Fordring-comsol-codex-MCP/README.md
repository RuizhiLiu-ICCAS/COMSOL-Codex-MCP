# Fordring COMSOL Codex MCP

Portable COMSOL GUI MCP package for Codex. It controls an already-open COMSOL Desktop model by pasting COMSOL Java API code into Java Shell and executing it with Ctrl+Enter.

## Requirements

- Windows
- COMSOL Desktop 6.3 or newer
- Python 3.10 or newer
- COMSOL Desktop, the target model, and Java Shell opened manually

## Run

```powershell
.\start_server.ps1
```

If PowerShell execution policy blocks `.ps1` files, run:

```bat
start_server.bat
```

The first run creates `.venv` and installs dependencies automatically. Later runs reuse the local environment.

## Codex MCP Config

Replace the path with the extracted folder path:

```toml
[mcp_servers.comsol_gui]
command = "powershell.exe"
args = ["-NoProfile", "-ExecutionPolicy", "Bypass", "-File", "C:\\path\\to\\Fordring-comsol-codex-MCP\\start_server.ps1"]
```

## Tools

- `gui_status`
- `ensure_java_shell`
- `execute_java_shell`
- `set_global_parameter`
- `get_java_shell_output`
- `capture_comsol_window`
- `capture_graphics_panel`
- `list_comsol_reference_tables`
- `search_comsol_physics_ids`
- `search_comsol_physics_feature_ids`
- `search_comsol_boundary_feature_ids`

The MCP does not save COMSOL models automatically. Save changes manually in COMSOL Desktop.
